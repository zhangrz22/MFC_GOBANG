﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 GoBang.rc 使用
//
#define IDD_GOBANG_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDC_BLACK                       130
#define IDC_WHITE                       131
#define IDB_BACKGROUNDIMAGE             138
#define IDC_START                       1001
#define IDC_QUIT                        1002
#define IDC_ENDGAME                     1003
#define IDC_REPENTANCE                  1004
#define IDC_SAVE                        1005
#define IDC_OPEN                        1006
#define IDC_BUTTON1                     1011
#define IDC_BUTTON_AI                   1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
